namespace vega.Controllers.Resources
{
    public class KeyValuePairResource
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}